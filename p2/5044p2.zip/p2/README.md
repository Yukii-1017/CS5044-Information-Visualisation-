Open Chrome
run the application in browsers
、、、
https://ikl.host.cs.st-andrews.ac.uk/index
、、、
Home page
- click Director and Actors-160015074
  - view visual information for director and actors,bubblechart
- click Director and Genre-200015498
  - view visual information for director and genre,linechart
- click Director and Country-200024763
  - view visual information for director and country,mapchart

